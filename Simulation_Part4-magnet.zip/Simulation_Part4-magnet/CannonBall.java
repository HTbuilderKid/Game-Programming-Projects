import java.util.*;

public class CannonBall extends SimulationActor
{
    private static final double GRAVITY = 9.8;
    private static final double MAGNETIC_CONSTANT = 20.0;  
    private static final double MAX_DISTANCE = 10.0;       
    private static final double SOFTENING = 0.5;           

    public CannonBall()
    {
        super(null, new Vector2D(0.0, 0.0), new Vector2D(0.0, GRAVITY));
    }

    @Override
    public void act()
    {
        applyMagneticAttraction();   
        super.act();              
    }

    private void applyMagneticAttraction()
    {
        SimulationWorld world = (SimulationWorld) getWorld();
        List<CannonBall> balls = world.getObjects(CannonBall.class);

        if (balls == null || this.getPosition() == null)
            return;

        Vector2D totalAcceleration = new Vector2D(0.0, GRAVITY);

        for (CannonBall other : balls)
        {
            if (other == this || other.getPosition() == null) continue;

            Vector2D direction = Vector2D.substract(other.getPosition(), this.getPosition());
            double distance = direction.magnitude();
            if (distance < SOFTENING || distance > MAX_DISTANCE)
                continue;

            direction.normalize();
            double strength = MAGNETIC_CONSTANT / (distance * distance + SOFTENING);
            Vector2D attraction = Vector2D.multiply(direction, strength);
            totalAcceleration = Vector2D.add(totalAcceleration, attraction);
        }

        this.setAcceleration(totalAcceleration);
    }
}