import greenfoot.*;  // (World, Actor, GreenfootImage, Greenfoot and MouseInfo)
import java.util.*;
    
    /**
     * Write a description of class MyWorld here.
     * 
     * @author (your name) 
     * @version (a version number or a date)
     */
public class MyWorld extends SimulationWorld
{
    private final static double CAMERA_SPEED = 5.0; // 1 meter per second
        
    public MyWorld()
    {
        super(1024, 768, new Point2D(8.0, 6.0), 16.0); 
        prepare();
    }
    
    public void act()
    {
        super.act();
        moveCamera();
        handleCannonBallCollision();
        reflectionOnWindowEdge();
    }
    
    void handleCannonBallCollision()
    {
        List<CannonBall> balls = getObjects(CannonBall.class);
        for (int i = 0; i < balls.size(); i++) {
            for (int j = i + 1; j < balls.size(); j++) {
                CannonBall ball1 = balls.get(i);
                CannonBall ball2 = balls.get(j);
                
                Vector2D ball1ToBall2 = new Vector2D(ball2.getX() - ball1.getY(), ball2.getY() - ball1.getY());;
                double distance = ball1ToBall2.magnitude();
                double ball1Radius = ball1.getImage().getHeight() / 2;
                double ball2Radius = ball2.getImage().getHeight() / 2;
                
                if (distance < ball1Radius + ball2Radius) {
                    collisionResponse(ball1, ball2);
                }
            }
        }
    }
    
    void collisionResponse(CannonBall ball1, CannonBall ball2) 
    {
        if (ball1.getPosition() == null || ball2.getPosition() == null) {
            return;
        }
        Vector2D n = Vector2D.substract(ball2.getPosition(), ball2.getPosition());
        double distance = n.magnitude();
        double ball1Radius = windowToWorld(ball1.getImage().getHeight() / 2);
        double ball2Radius = windowToWorld(ball2.getImage().getHeight() / 2);
        
        double overlap = distance - ball1Radius - ball2Radius;
        
        n.normalize();
        Vector2D t = new Vector2D(-n.getY(), n.getX());
        
        ball1.getPosition().add(Vector2D.multiply(n, overlap / 2));
        ball2.getPosition().add(Vector2D.multiply(n, overlap / 2));
        
        Vector2D v1t = Vector2D.multiply(t, Vector2D.dot(ball1.getVelocity(), t));
        Vector2D v1n = Vector2D.multiply(n, Vector2D.dot(ball1.getVelocity(), n));
        Vector2D v2t = Vector2D.multiply(t, Vector2D.dot(ball2.getVelocity(), t));
        Vector2D v2n = Vector2D.multiply(n, Vector2D.dot(ball2.getVelocity(), n));
        
        ball1.setVelocity(Vector2D.add(v1t, v2t));
        ball2.setVelocity(Vector2D.add(v2t, v1t));
    }
    
    public void reflectionOnWindowEdge()
    {
        List<CannonBall> balls = getObjects(CannonBall.class);
        for (int i = 0; i < balls.size(); i++) {
            CannonBall ball = balls.get(i);
            if(ball.getX() < 0) {
                ball.setVelocity(new Vector2D(Math.abs(ball.getVelocity().getX()), ball.getVelocity().getY()));
            }
            if(ball.getX() > getWidth()) {
                ball.setVelocity(new Vector2D(-Math.abs(ball.getVelocity().getX()), ball.getVelocity().getY()));
            }
            if(ball.getY() < 0) {
                ball.setVelocity(new Vector2D(ball.getVelocity().getX(), -Math.abs(ball.getVelocity().getY())));
            }
            if(ball.getY() > getHeight()) {
                ball.setVelocity(new Vector2D(ball.getVelocity().getX(), Math.abs(ball.getVelocity().getY())));
            }
        }
    }
    
    public void moveCamera()
    {
        double dt = getTimeStepDuration();
            
        if (Greenfoot.isKeyDown("a")){
            cameraCenter.setX(cameraCenter.getX() - CAMERA_SPEED * dt);
        }
        if (Greenfoot.isKeyDown("d")){
            cameraCenter.setX(cameraCenter.getX() + CAMERA_SPEED * dt);
        }
        if (Greenfoot.isKeyDown("s")){
            cameraCenter.setY(cameraCenter.getY() - CAMERA_SPEED * dt);
        }        
        if (Greenfoot.isKeyDown("w")){
            cameraCenter.setY(cameraCenter.getY() + CAMERA_SPEED * dt);
        }
        if (Greenfoot.isKeyDown("-")){
            cameraWidth += CAMERA_SPEED * dt;
            scaleActors();
        }
        if (Greenfoot.isKeyDown("=") || Greenfoot.isKeyDown("+")){
            cameraWidth -= CAMERA_SPEED * dt;
            scaleActors();
        }    
    }
    
    /**
     * Prepare the world for the start of the program.
     * That is: create the initial objects and add them to the world.
     */
    private void prepare()
    {
        Cannon cannon = new Cannon();
        addObject(cannon,128,419);
        Target target = new Target();
        addObject(target,517,116);
        Target target2 = new Target();
        addObject(target2,602,190);
        target2.setLocation(626,216);
        Target target3 = new Target();
        addObject(target3,626,216);
        addObject(target3,660,310);
        target3.setLocation(660,291);
        Target target4 = new Target();
        addObject(target4,660,291);
        removeObject(target4);
        Target target5 = new Target();
        addObject(target5,735,552);
        target3.setLocation(693,367);
        CannonBall cannonBall = new CannonBall();
        addObject(cannonBall,244,122);
        CannonBall cannonBall2 = new CannonBall();
        addObject(cannonBall2,270,121);
        cannonBall2.setLocation(270,108);
        Cannon cannon2 = new Cannon();
        addObject(cannon2,460,658);
        Cannon cannon3 = new Cannon();
        addObject(cannon3,872,414);
    }
}
